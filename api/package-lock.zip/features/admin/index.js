const adminRoutes = require('./admin.routes');
const adminController = require('./admin.controller');
const adminModel = require('./admin.model');

module.exports = {
  adminRoutes,
  adminController,
  adminModel
}; 