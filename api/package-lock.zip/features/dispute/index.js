const disputeRoutes = require('./dispute.routes.js');

module.exports = {
  disputeRoutes
}; 